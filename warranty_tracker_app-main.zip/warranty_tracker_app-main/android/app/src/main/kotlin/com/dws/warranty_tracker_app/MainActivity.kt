package com.dws.warranty_tracker_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
